﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EPC232.model;

namespace EPC232.game.elements
{
    /// <summary>
    /// Interaction logic for GamePlayersInput.xaml
    /// </summary>
    public partial class GamePlayersInput : Window
    {
        int iHome = 0;
        int iGuests = 0;

        string insertionString = "";

        ValuePlayers player;

        private ObservableCollection<string> plInfoHome = new ObservableCollection<string>();
        private ObservableCollection<string> plInfoGuests = new ObservableCollection<string>();

        ListExportDialogueBox ledb;// = new ListExportDialogueBox();

        #region Getters & setters
        /***********************************************************************
         * Getters & setters
         **********************************************************************/

        public void setPlayer(ValuePlayers playerIn)
        {
            player = playerIn;
        }

        #endregion

        public GamePlayersInput(ValuePlayers playerIn)
        {
            player = playerIn;

            InitializeComponent();

            // source bio player.plInfo**
            listBoxHome.ItemsSource = plInfoHome;
            listBoxGuests.ItemsSource = plInfoGuests;
        }

        #region Click - INSERT functions
        private void InsertHome_Click(object sender, RoutedEventArgs e)
        {
            if (insertNumber.Text != "" || inName.Text != "")
            {
                int insertNumber;
                int insertName;
                bool isDigitCheck = int.TryParse(this.insertNumber.Text, out insertNumber);
                bool isNameValid = int.TryParse(inName.Text, out insertName);

                if (isDigitCheck == false || isNameValid == true)
                {
                    MessageBox.Show("Invalid input!", "Warning!", MessageBoxButton.OK);
                }
                else
                {
                    if (player.isHomeListFull == false && insertNumber < 100 && insertNumber > 0)
                    {
                        iHome++;

                        insertionString = insertNumber.ToString() + ", " + inName.Text;

                        plInfoHome.Add(insertionString);
                        player.plInfoHome[iHome] = insertionString;

                        inName.Text = string.Empty;
                        this.insertNumber.Text = string.Empty;

                        if (iHome == player.allowedPPT)
                        {
                            player.isHomeListFull = true;
                        }
                    }
                    else
                    {
                        MessageBox.Show("List population limit achieved", "Error", MessageBoxButton.OK);
                    }
                }
            }
            else
            {
                MessageBox.Show("Input empty.", "Warning!", MessageBoxButton.OK);
            }
        }

        private void InsertGuests_Click(object sender, RoutedEventArgs e)
        {
            if (insertNumber.Text != "" || inName.Text != "")
            {
                int insertNumber;
                int insertName;
                bool isDigitCheck = int.TryParse(this.insertNumber.Text, out insertNumber);
                bool isNameValid = int.TryParse(inName.Text, out insertName);

                if (isDigitCheck == false || isNameValid == true)
                {
                    MessageBox.Show("Invalid input!", "Warning!", MessageBoxButton.OK);
                }
                else
                {
                    if (player.isGuestsListFull == false && insertNumber < 99 && insertNumber > 0)
                    {
                        iGuests++;

                        insertionString = insertNumber.ToString() + ", " + inName.Text;

                        plInfoGuests.Add(insertionString);
                        player.plInfoGuests[iGuests] = insertionString;

                        inName.Text = string.Empty;
                        this.insertNumber.Text = string.Empty;

                        if (iGuests == player.allowedPPT)
                        {
                            player.isGuestsListFull = true;
                        }
                    }
                    else
                    {
                        MessageBox.Show("List population limit achieved.", "Error", MessageBoxButton.OK);
                    }
                }
            }
            else
            {
                MessageBox.Show("Input empty.", "Warning!", MessageBoxButton.OK);
            }
        }
        #endregion

        #region Click - DELETE functions
        private void deleteGuests_ButtonClick(object sender, RoutedEventArgs e)
        {
            for (int i=0; i<listBoxGuests.Items.Count; i++)
            {
                if (listBoxGuests.SelectedIndex == i)
                {
                    player.plInfoGuests[i] = plInfoGuests[i] = null;     // bio iz player.

                    iGuests--;
                }
            }
        }

        private void deleteHome_ButtonClick(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < listBoxHome.Items.Count; i++)
            {
                if (listBoxHome.SelectedIndex == i)
                {
                    player.plInfoHome[i] = plInfoHome[i] = null;    // bio iz player.

                    iHome--;
                }
            }
        }
        #endregion

        private void acceptButton_Click(object sender, RoutedEventArgs e)
        {
            if (listBoxGuests.Items.Count==0 || listBoxHome.Items.Count==0)
            {
                var msg = MessageBox.Show("Lists not loaded correctly.", "Error", MessageBoxButton.OK);
            } else
            {
                Close();
            }
        }

        private void exportButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ListExportDialogueBox ledb = new ListExportDialogueBox();
                ledb.Show();
            } catch (Exception exc)
            {
                var msg = MessageBox.Show("Error code: " + exc.StackTrace.ToString(), "Error", MessageBoxButton.OK);
            }
            
        }
    }
}
